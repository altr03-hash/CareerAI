#!/usr/bin/env bash
cd "$(dirname "$0")"
bash scripts/launch.sh
