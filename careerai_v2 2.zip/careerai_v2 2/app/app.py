"""
=============================================================
 CareerAI v2.0 — Интеллектуальная система карьерного развития
 Flask + SQLite + TF-IDF + scikit-learn
 Запуск: python app/app.py
=============================================================
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for, g
import sqlite3, hashlib, json, uuid, os, re
from datetime import datetime, timedelta
from functools import wraps

# ── scikit-learn imports (graceful fallback) ─────────────────────────
try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    import numpy as np
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, "careerai.db")

app = Flask(__name__,
            template_folder=os.path.join(BASE_DIR, "..", "templates"),
            static_folder=os.path.join(BASE_DIR, "..", "static"))
app.secret_key = os.environ.get("SECRET_KEY", "careerai-super-secret-key-2024")
app.permanent_session_lifetime = timedelta(days=30)

# ─────────────────────────────────────────────
# БАЗА ДАННЫХ ПРОФЕССИЙ (из оригинального app.py)
# ─────────────────────────────────────────────
PROFESSIONS = {
    "Data Analyst": {
        "required_skills": ["Python","SQL","Excel","Pandas","Matplotlib","Statistics","Tableau","Power BI","Data Visualization","NumPy"],
        "description": "Специалист по анализу данных собирает, обрабатывает и интерпретирует большие массивы данных для поддержки бизнес-решений.",
        "recommended_courses": ["SQL для начинающих — Stepik","Python для анализа данных — Coursera","Tableau Desktop — Udemy","Google Data Analytics Certificate"],
        "emoji": "📊", "color": "#4F8EF7",
    },
    "Backend Developer": {
        "required_skills": ["Python","Django","FastAPI","REST API","SQL","PostgreSQL","Docker","Git","Redis","Linux"],
        "description": "Backend-разработчик проектирует и реализует серверную логику приложений.",
        "recommended_courses": ["Django REST Framework — официальная документация","FastAPI — Udemy / YouTube","PostgreSQL для разработчиков — Stepik","Docker & Kubernetes — Coursera"],
        "emoji": "⚙️", "color": "#22C55E",
    },
    "Frontend Developer": {
        "required_skills": ["HTML","CSS","JavaScript","React","TypeScript","Git","Figma","REST API","Webpack","Sass"],
        "description": "Frontend-разработчик создаёт пользовательские интерфейсы веб-приложений.",
        "recommended_courses": ["JavaScript.info — бесплатный учебник","React — официальная документация + Scrimba","CSS Grid & Flexbox — freeCodeCamp","TypeScript — Udemy"],
        "emoji": "🎨", "color": "#F59E0B",
    },
    "ML Engineer": {
        "required_skills": ["Python","scikit-learn","TensorFlow","PyTorch","Pandas","NumPy","Mathematics","Statistics","Docker","MLflow"],
        "description": "Инженер машинного обучения разрабатывает, обучает и развёртывает ML-модели в продакшн-среде.",
        "recommended_courses": ["Machine Learning — Andrew Ng (Coursera)","Deep Learning Specialization — deeplearning.ai","Kaggle — бесплатные курсы","MLOps Specialization — Coursera"],
        "emoji": "🤖", "color": "#8B5CF6",
    },
    "DevOps Engineer": {
        "required_skills": ["Linux","Docker","Kubernetes","CI/CD","Git","Jenkins","Terraform","AWS","Ansible","Monitoring"],
        "description": "DevOps-инженер обеспечивает непрерывную интеграцию и доставку программного обеспечения.",
        "recommended_courses": ["Linux для системных администраторов — Stepik","Docker & Kubernetes — A-Cloud-Guru","AWS Certified Solutions Architect — Udemy","HashiCorp Terraform — документация"],
        "emoji": "🛠️", "color": "#EF4444",
    },
    "Cybersecurity Specialist": {
        "required_skills": ["Networking","Linux","Python","Cryptography","Penetration Testing","Firewalls","SIEM","Ethical Hacking","Risk Analysis","OWASP"],
        "description": "Специалист по кибербезопасности защищает информационные системы от угроз и атак.",
        "recommended_courses": ["CompTIA Security+ — Professor Messer","Ethical Hacking — Udemy (Zaid Sabih)","TryHackMe / HackTheBox — практические платформы","CISSP — (ISC)²"],
        "emoji": "🔐", "color": "#06B6D4",
    },
    "Data Scientist": {
        "required_skills": ["Python","R","Statistics","Machine Learning","Pandas","NumPy","SQL","Data Visualization","Research","scikit-learn"],
        "description": "Data Scientist исследует данные для извлечения знаний и формулировки гипотез.",
        "recommended_courses": ["Data Science Specialization — Johns Hopkins (Coursera)","Applied Data Science with Python — Michigan","Statistics with Python — Coursera","Kaggle Data Science Courses"],
        "emoji": "🔬", "color": "#EC4899",
    },
    "Mobile Developer": {
        "required_skills": ["Swift","Kotlin","Flutter","Dart","React Native","Git","REST API","Firebase","UI/UX","Android"],
        "description": "Мобильный разработчик создаёт нативные и кроссплатформенные приложения для iOS и Android.",
        "recommended_courses": ["Flutter & Dart — Udemy","Android Kotlin Fundamentals — Google Codelabs","Swift UI — Apple Developer Documentation","React Native — документация"],
        "emoji": "📱", "color": "#10B981",
    },
}

MINI_TESTS = {
    "Python": [
        {"q": "Что выведет print(type([]))?", "opts": ["<class 'list'>","<class 'array'>","list","Array"], "a": 0},
        {"q": "Как называется срез списка lst[2:5]?", "opts": ["Слайс","Индекс","Срез","Подмассив"], "a": 2},
        {"q": "Что делает метод .strip()?", "opts": ["Удаляет пробелы по краям","Разбивает строку","Объединяет строки","Переводит в нижний регистр"], "a": 0},
    ],
    "SQL": [
        {"q": "Какой оператор выбирает уникальные значения?", "opts": ["UNIQUE","DISTINCT","ONLY","SINGLE"], "a": 1},
        {"q": "Что делает LEFT JOIN?", "opts": ["Возвращает только совпадения","Возвращает все строки левой таблицы","Возвращает все строки правой таблицы","Объединяет без совпадений"], "a": 1},
        {"q": "Функция для подсчёта строк?", "opts": ["SUM()","COUNT()","TOTAL()","NUM()"], "a": 1},
    ],
    "JavaScript": [
        {"q": "Что выведет typeof null?", "opts": ["'null'","'object'","'undefined'","'boolean'"], "a": 1},
        {"q": "Как объявить стрелочную функцию?", "opts": ["function() =>","() => {}","=> function()","func () =>"], "a": 1},
        {"q": "Что делает метод Array.map()?", "opts": ["Фильтрует массив","Создаёт новый массив через преобразование","Суммирует элементы","Сортирует массив"], "a": 1},
    ],
    "Docker": [
        {"q": "Команда для запуска контейнера?", "opts": ["docker start","docker run","docker exec","docker up"], "a": 1},
        {"q": "Что такое Dockerfile?", "opts": ["Файл конфигурации сети","Инструкция для создания образа","Логи контейнера","Список зависимостей"], "a": 1},
        {"q": "Команда для просмотра запущенных контейнеров?", "opts": ["docker list","docker ps","docker show","docker containers"], "a": 1},
    ],
    "Git": [
        {"q": "Команда для создания новой ветки и переключения на неё?", "opts": ["git branch new","git checkout -b new","git new branch","git switch --create new"], "a": 1},
        {"q": "Что делает git stash?", "opts": ["Удаляет изменения","Временно сохраняет изменения","Создаёт коммит","Синхронизирует с remote"], "a": 1},
        {"q": "Что такое git rebase?", "opts": ["Удаление ветки","Перемещение коммитов на другую базу","Создание тега","Откат последнего коммита"], "a": 1},
    ],
}

# ─────────────────────────────────────────────
# БД — инициализация
# ─────────────────────────────────────────────
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, detect_types=sqlite3.PARSE_DECLTYPES)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop("db", None)
    if db: db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id          TEXT PRIMARY KEY,
            username    TEXT UNIQUE NOT NULL,
            email       TEXT UNIQUE NOT NULL,
            password    TEXT NOT NULL,
            created_at  TEXT NOT NULL,
            is_blocked  INTEGER DEFAULT 0,
            level       INTEGER DEFAULT 1,
            xp          INTEGER DEFAULT 0,
            avatar_seed TEXT DEFAULT 'default'
        );

        CREATE TABLE IF NOT EXISTS user_skills (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     TEXT NOT NULL,
            skill_name  TEXT NOT NULL,
            skill_level INTEGER DEFAULT 0,
            updated_at  TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS test_results (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     TEXT NOT NULL,
            discipline  TEXT NOT NULL,
            score       INTEGER NOT NULL,
            max_score   INTEGER NOT NULL,
            pct         REAL NOT NULL,
            prev_pct    REAL DEFAULT 0,
            taken_at    TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS analyses (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     TEXT NOT NULL,
            skills_raw  TEXT NOT NULL,
            results_json TEXT NOT NULL,
            created_at  TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS onboarding (
            user_id     TEXT PRIMARY KEY,
            answers     TEXT NOT NULL,
            completed   INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS activity_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     TEXT,
            action      TEXT NOT NULL,
            detail      TEXT,
            ip          TEXT,
            created_at  TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS admin_settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );

        INSERT OR IGNORE INTO admin_settings VALUES ('admin_password', '""" + hash_pw("admin123") + """');
        INSERT OR IGNORE INTO admin_settings VALUES ('site_title', 'CareerAI');
        INSERT OR IGNORE INTO admin_settings VALUES ('site_subtitle', 'Интеллектуальная система карьерного развития');
        INSERT OR IGNORE INTO admin_settings VALUES ('logo_emoji', '🎯');
        """)
        db.commit()

def hash_pw(pw: str) -> str:
    return hashlib.sha256(pw.encode()).hexdigest()

def now_str():
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

def log_action(action, detail="", user_id=None):
    try:
        db = get_db()
        db.execute("INSERT INTO activity_log (user_id,action,detail,ip,created_at) VALUES (?,?,?,?,?)",
                   (user_id or session.get("user_id"), action, detail,
                    request.remote_addr, now_str()))
        db.commit()
    except: pass

# ─────────────────────────────────────────────
# AUTH HELPERS
# ─────────────────────────────────────────────
def require_login(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return jsonify({"error": "not_authenticated"}), 401
        return f(*args, **kwargs)
    return decorated

def require_admin(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("is_admin"):
            return jsonify({"error": "forbidden"}), 403
        return f(*args, **kwargs)
    return decorated

def get_setting(key):
    db = get_db()
    row = db.execute("SELECT value FROM admin_settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else ""

# ─────────────────────────────────────────────
# SKILL ANALYSIS (из оригинального app.py)
# ─────────────────────────────────────────────
def parse_skills(raw):
    skills = [s.strip() for s in raw.replace("\n", ",").split(",")]
    return [s for s in skills if s]

def compute_similarity(user_skills):
    if not SKLEARN_AVAILABLE:
        return _fallback_similarity(user_skills)
    user_doc = " ".join(user_skills).lower()
    prof_names = list(PROFESSIONS.keys())
    prof_docs  = [" ".join(PROFESSIONS[p]["required_skills"]).lower() for p in prof_names]
    corpus = [user_doc] + prof_docs
    vectorizer = TfidfVectorizer(analyzer="word", token_pattern=r"[a-zA-Z0-9/_.+#-]+")
    mat = vectorizer.fit_transform(corpus)
    sims = cosine_similarity(mat[0], mat[1:])[0]
    user_lower = [s.lower() for s in user_skills]
    results = []
    for i, pname in enumerate(prof_names):
        req = PROFESSIONS[pname]["required_skills"]
        req_lower = [r.lower() for r in req]
        matched = [r for r in req_lower if r in user_lower]
        missing = [r for r in req if r.lower() not in user_lower]
        exact_pct = len(matched) / len(req) * 100 if req else 0
        score = round(0.4 * float(sims[i]) * 100 + 0.6 * exact_pct, 1)
        results.append({
            "profession": pname,
            "score": score,
            "exact_match_pct": round(exact_pct, 1),
            "matched_skills": matched,
            "missing_skills": missing[:8],
            "description": PROFESSIONS[pname]["description"],
            "courses": PROFESSIONS[pname]["recommended_courses"],
            "emoji": PROFESSIONS[pname]["emoji"],
            "color": PROFESSIONS[pname]["color"],
        })
    results.sort(key=lambda x: x["score"], reverse=True)
    return results

def _fallback_similarity(user_skills):
    user_lower = [s.lower() for s in user_skills]
    results = []
    for pname, pdata in PROFESSIONS.items():
        req = pdata["required_skills"]
        req_lower = [r.lower() for r in req]
        matched = [r for r in req_lower if r in user_lower]
        missing = [r for r in req if r.lower() not in user_lower]
        pct = round(len(matched) / len(req) * 100, 1) if req else 0
        results.append({
            "profession": pname, "score": pct, "exact_match_pct": pct,
            "matched_skills": matched, "missing_skills": missing[:8],
            "description": pdata["description"], "courses": pdata["recommended_courses"],
            "emoji": pdata["emoji"], "color": pdata["color"],
        })
    results.sort(key=lambda x: x["score"], reverse=True)
    return results

# ─────────────────────────────────────────────
# ROUTES — PAGES
# ─────────────────────────────────────────────
@app.route("/")
def index():
    site_title    = get_setting("site_title")
    site_subtitle = get_setting("site_subtitle")
    logo_emoji    = get_setting("logo_emoji")
    user = None
    if "user_id" in session:
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    return render_template("index.html",
                           site_title=site_title,
                           site_subtitle=site_subtitle,
                           logo_emoji=logo_emoji,
                           user=user,
                           professions=list(PROFESSIONS.keys()),
                           mini_test_skills=list(MINI_TESTS.keys()))

@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect("/")
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    if not user:
        session.clear()
        return redirect("/")
    skills = db.execute(
        "SELECT * FROM user_skills WHERE user_id=? ORDER BY updated_at DESC",
        (user["id"],)).fetchall()
    tests = db.execute(
        "SELECT * FROM test_results WHERE user_id=? ORDER BY taken_at DESC LIMIT 20",
        (user["id"],)).fetchall()
    analyses = db.execute(
        "SELECT * FROM analyses WHERE user_id=? ORDER BY created_at DESC LIMIT 5",
        (user["id"],)).fetchall()
    onboarding_done = db.execute(
        "SELECT completed FROM onboarding WHERE user_id=?", (user["id"],)).fetchone()
    site_title  = get_setting("site_title")
    logo_emoji  = get_setting("logo_emoji")
    return render_template("dashboard.html",
                           user=user, skills=skills, tests=tests,
                           analyses=analyses,
                           onboarding_done=onboarding_done and onboarding_done["completed"],
                           site_title=site_title, logo_emoji=logo_emoji)

@app.route("/admin")
def admin_page():
    if not session.get("is_admin"):
        return redirect("/")
    db = get_db()
    users = db.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()
    logs  = db.execute("SELECT * FROM activity_log ORDER BY created_at DESC LIMIT 100").fetchall()
    stats = {
        "total_users":    db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        "total_tests":    db.execute("SELECT COUNT(*) FROM test_results").fetchone()[0],
        "total_analyses": db.execute("SELECT COUNT(*) FROM analyses").fetchone()[0],
        "today_reg":      db.execute("SELECT COUNT(*) FROM users WHERE created_at LIKE ?",
                                     (datetime.utcnow().strftime("%Y-%m-%d") + "%",)).fetchone()[0],
    }
    settings = {r["key"]: r["value"] for r in db.execute("SELECT * FROM admin_settings").fetchall()}
    site_title  = settings.get("site_title", "CareerAI")
    logo_emoji  = settings.get("logo_emoji", "🎯")
    return render_template("admin.html",
                           users=users, logs=logs, stats=stats,
                           settings=settings, site_title=site_title, logo_emoji=logo_emoji)

# ─────────────────────────────────────────────
# API — AUTH
# ─────────────────────────────────────────────
@app.route("/api/register", methods=["POST"])
def api_register():
    data = request.get_json()
    username = data.get("username","").strip()
    email    = data.get("email","").strip().lower()
    pw       = data.get("password","")
    pw2      = data.get("password2","")

    if not username or not email or not pw:
        return jsonify({"error": "Заполните все поля"}), 400
    if len(username) < 3:
        return jsonify({"error": "Имя пользователя минимум 3 символа"}), 400
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        return jsonify({"error": "Некорректный email"}), 400
    if len(pw) < 6:
        return jsonify({"error": "Пароль минимум 6 символов"}), 400
    if pw != pw2:
        return jsonify({"error": "Пароли не совпадают"}), 400

    db = get_db()
    if db.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone():
        return jsonify({"error": "Email уже зарегистрирован"}), 409
    if db.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone():
        return jsonify({"error": "Имя пользователя занято"}), 409

    uid = str(uuid.uuid4())
    db.execute("INSERT INTO users (id,username,email,password,created_at,avatar_seed) VALUES (?,?,?,?,?,?)",
               (uid, username, email, hash_pw(pw), now_str(), username[:8]))
    db.commit()

    session.permanent = True
    session["user_id"]  = uid
    session["username"] = username
    session["is_admin"] = False
    log_action("register", f"New user: {username}", uid)
    return jsonify({"ok": True, "redirect": "/dashboard"})

@app.route("/api/login", methods=["POST"])
def api_login():
    data  = request.get_json()
    email = data.get("email","").strip().lower()
    pw    = data.get("password","")

    db  = get_db()
    row = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not row or row["password"] != hash_pw(pw):
        return jsonify({"error": "Неверный email или пароль"}), 401
    if row["is_blocked"]:
        return jsonify({"error": "Аккаунт заблокирован"}), 403

    session.permanent = True
    session["user_id"]  = row["id"]
    session["username"] = row["username"]
    session["is_admin"] = False
    log_action("login", "", row["id"])
    return jsonify({"ok": True, "redirect": "/dashboard"})

@app.route("/api/admin-login", methods=["POST"])
def api_admin_login():
    data = request.get_json()
    pw   = data.get("password","")
    db   = get_db()
    stored = db.execute("SELECT value FROM admin_settings WHERE key='admin_password'").fetchone()
    if not stored or stored["value"] != hash_pw(pw):
        return jsonify({"error": "Неверный пароль администратора"}), 401
    session["is_admin"]  = True
    session["user_id"]   = "admin"
    session["username"]  = "Administrator"
    log_action("admin_login")
    return jsonify({"ok": True, "redirect": "/admin"})

@app.route("/api/logout", methods=["POST"])
def api_logout():
    log_action("logout")
    session.clear()
    return jsonify({"ok": True})

# ─────────────────────────────────────────────
# API — ANALYSIS
# ─────────────────────────────────────────────
@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    data   = request.get_json()
    raw    = data.get("skills","").strip()
    if not raw:
        return jsonify({"error": "Введите навыки"}), 400

    skills  = parse_skills(raw)
    results = compute_similarity(skills)

    if "user_id" in session and session["user_id"] != "admin":
        db = get_db()
        uid = session["user_id"]
        db.execute("INSERT INTO analyses (user_id,skills_raw,results_json,created_at) VALUES (?,?,?,?)",
                   (uid, raw, json.dumps(results[:5], ensure_ascii=False), now_str()))
        # Update user skills
        for skill in skills:
            existing = db.execute(
                "SELECT id,skill_level FROM user_skills WHERE user_id=? AND LOWER(skill_name)=LOWER(?)",
                (uid, skill)).fetchone()
            if existing:
                db.execute("UPDATE user_skills SET updated_at=? WHERE id=?",
                           (now_str(), existing["id"]))
            else:
                db.execute("INSERT INTO user_skills (user_id,skill_name,skill_level,updated_at) VALUES (?,?,?,?)",
                           (uid, skill, 1, now_str()))
        # XP gain
        db.execute("UPDATE users SET xp=xp+10 WHERE id=?", (uid,))
        db.commit()
        log_action("analyze", f"{len(skills)} skills", uid)

    return jsonify({"ok": True, "results": results[:8], "skills": skills})

# ─────────────────────────────────────────────
# API — MINI TESTS
# ─────────────────────────────────────────────
@app.route("/api/test/<discipline>")
def api_get_test(discipline):
    if discipline not in MINI_TESTS:
        return jsonify({"error": "Тест не найден"}), 404
    questions = MINI_TESTS[discipline]
    # Return questions without answers
    safe = [{"q": q["q"], "opts": q["opts"]} for q in questions]
    return jsonify({"ok": True, "discipline": discipline, "questions": safe})

@app.route("/api/test/<discipline>/submit", methods=["POST"])
def api_submit_test(discipline):
    if discipline not in MINI_TESTS:
        return jsonify({"error": "Тест не найден"}), 404
    data    = request.get_json()
    answers = data.get("answers", [])
    questions = MINI_TESTS[discipline]

    score = sum(1 for i, q in enumerate(questions) if i < len(answers) and answers[i] == q["a"])
    max_s = len(questions)
    pct   = round(score / max_s * 100, 1)
    prev  = 0

    if "user_id" in session and session["user_id"] != "admin":
        uid = session["user_id"]
        db  = get_db()
        prev_row = db.execute(
            "SELECT pct FROM test_results WHERE user_id=? AND discipline=? ORDER BY taken_at DESC LIMIT 1",
            (uid, discipline)).fetchone()
        if prev_row:
            prev = prev_row["pct"]

        db.execute("INSERT INTO test_results (user_id,discipline,score,max_score,pct,prev_pct,taken_at) VALUES (?,?,?,?,?,?,?)",
                   (uid, discipline, score, max_s, pct, prev, now_str()))

        # Update skill level
        existing = db.execute(
            "SELECT id FROM user_skills WHERE user_id=? AND LOWER(skill_name)=LOWER(?)",
            (uid, discipline)).fetchone()
        lvl = max(1, int(pct / 25))
        if existing:
            db.execute("UPDATE user_skills SET skill_level=?,updated_at=? WHERE id=?",
                       (lvl, now_str(), existing["id"]))
        else:
            db.execute("INSERT INTO user_skills (user_id,skill_name,skill_level,updated_at) VALUES (?,?,?,?)",
                       (uid, discipline, lvl, now_str()))

        db.execute("UPDATE users SET xp=xp+? WHERE id=?", (score * 5, uid))
        db.commit()
        log_action("test", f"{discipline}: {pct}%", uid)

    improvement = round(pct - prev, 1)
    return jsonify({
        "ok": True, "score": score, "max": max_s, "pct": pct,
        "prev_pct": prev, "improvement": improvement,
        "answers": [q["a"] for q in questions]
    })

# ─────────────────────────────────────────────
# API — ONBOARDING
# ─────────────────────────────────────────────
@app.route("/api/onboarding", methods=["POST"])
@require_login
def api_onboarding():
    data    = request.get_json()
    answers = data.get("answers", {})
    uid     = session["user_id"]
    db      = get_db()
    db.execute(
        "INSERT OR REPLACE INTO onboarding (user_id,answers,completed) VALUES (?,?,1)",
        (uid, json.dumps(answers, ensure_ascii=False)))
    db.commit()
    log_action("onboarding", "", uid)
    return jsonify({"ok": True})

# ─────────────────────────────────────────────
# API — USER PROFILE
# ─────────────────────────────────────────────
@app.route("/api/me")
@require_login
def api_me():
    uid = session["user_id"]
    db  = get_db()
    user = db.execute("SELECT id,username,email,created_at,level,xp FROM users WHERE id=?", (uid,)).fetchone()
    if not user:
        return jsonify({"error": "not found"}), 404
    skills = db.execute("SELECT * FROM user_skills WHERE user_id=? ORDER BY updated_at DESC", (uid,)).fetchall()
    tests  = db.execute("SELECT * FROM test_results WHERE user_id=? ORDER BY taken_at DESC LIMIT 10", (uid,)).fetchall()
    return jsonify({
        "ok": True,
        "user": dict(user),
        "skills": [dict(s) for s in skills],
        "tests":  [dict(t) for t in tests],
    })

@app.route("/api/me/username", methods=["POST"])
@require_login
def api_change_username():
    data = request.get_json()
    new_name = data.get("username","").strip()
    if len(new_name) < 3:
        return jsonify({"error": "Минимум 3 символа"}), 400
    uid = session["user_id"]
    db  = get_db()
    if db.execute("SELECT id FROM users WHERE username=? AND id!=?", (new_name, uid)).fetchone():
        return jsonify({"error": "Имя занято"}), 409
    db.execute("UPDATE users SET username=? WHERE id=?", (new_name, uid))
    db.commit()
    session["username"] = new_name
    log_action("change_username", new_name)
    return jsonify({"ok": True})

# ─────────────────────────────────────────────
# API — ADMIN
# ─────────────────────────────────────────────
@app.route("/api/admin/users")
@require_admin
def api_admin_users():
    db    = get_db()
    users = db.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()
    return jsonify({"ok": True, "users": [dict(u) for u in users]})

@app.route("/api/admin/user/<uid>", methods=["PATCH"])
@require_admin
def api_admin_patch_user(uid):
    data = request.get_json()
    db   = get_db()
    if "username" in data:
        db.execute("UPDATE users SET username=? WHERE id=?", (data["username"], uid))
    if "email" in data:
        db.execute("UPDATE users SET email=? WHERE id=?", (data["email"], uid))
    if "is_blocked" in data:
        db.execute("UPDATE users SET is_blocked=? WHERE id=?", (int(data["is_blocked"]), uid))
    db.commit()
    log_action("admin_edit_user", uid)
    return jsonify({"ok": True})

@app.route("/api/admin/user/<uid>", methods=["DELETE"])
@require_admin
def api_admin_delete_user(uid):
    db = get_db()
    db.execute("DELETE FROM users WHERE id=?", (uid,))
    db.execute("DELETE FROM user_skills WHERE user_id=?", (uid,))
    db.execute("DELETE FROM test_results WHERE user_id=?", (uid,))
    db.execute("DELETE FROM analyses WHERE user_id=?", (uid,))
    db.commit()
    log_action("admin_delete_user", uid)
    return jsonify({"ok": True})

@app.route("/api/admin/user/<uid>/clear-history", methods=["POST"])
@require_admin
def api_admin_clear_history(uid):
    db = get_db()
    db.execute("DELETE FROM user_skills WHERE user_id=?", (uid,))
    db.execute("DELETE FROM test_results WHERE user_id=?", (uid,))
    db.execute("DELETE FROM analyses WHERE user_id=?", (uid,))
    db.commit()
    log_action("admin_clear_history", uid)
    return jsonify({"ok": True})

@app.route("/api/admin/settings", methods=["POST"])
@require_admin
def api_admin_settings():
    data = request.get_json()
    db   = get_db()
    for key, val in data.items():
        if key == "admin_password" and val:
            val = hash_pw(val)
        db.execute("INSERT OR REPLACE INTO admin_settings (key,value) VALUES (?,?)", (key, val))
    db.commit()
    log_action("admin_settings")
    return jsonify({"ok": True})

@app.route("/api/admin/stats")
@require_admin
def api_admin_stats():
    db = get_db()
    stats = {
        "total_users":    db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        "total_tests":    db.execute("SELECT COUNT(*) FROM test_results").fetchone()[0],
        "total_analyses": db.execute("SELECT COUNT(*) FROM analyses").fetchone()[0],
        "blocked_users":  db.execute("SELECT COUNT(*) FROM users WHERE is_blocked=1").fetchone()[0],
        "reg_by_day":     [dict(r) for r in db.execute(
            "SELECT substr(created_at,1,10) as day, COUNT(*) as cnt FROM users GROUP BY day ORDER BY day DESC LIMIT 7"
        ).fetchall()],
    }
    return jsonify({"ok": True, "stats": stats})

if __name__ == "__main__":
    init_db()
    print("\n" + "="*55)
    print("  🎯  CareerAI v2.0 запущен!")
    print("  🌐  http://localhost:5001")
    print("  🔑  Админ: password = admin123")
    print("="*55 + "\n")
    app.run(debug=False, host="0.0.0.0", port=5001)
