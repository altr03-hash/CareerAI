@echo off
chcp 65001 >nul
echo.
echo   🎯  CareerAI v2.0
echo   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo   ❌  Python не найден. Установите Python 3.9+ с python.org
    pause
    exit /b 1
)

echo   📦  Установка зависимостей...
python -m pip install -q -r "%~dp0requirements.txt"

echo   ✅  Зависимости готовы
echo.
echo   🌐  Открывайте: http://localhost:5000
echo   🔑  Пароль администратора: admin123
echo   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
echo.

start "" "http://localhost:5000"
python "%~dp0app\app.py"
pause
