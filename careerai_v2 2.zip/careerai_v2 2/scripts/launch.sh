#!/usr/bin/env bash
# ============================================================
#  CareerAI v2.0 — Launch Script
# ============================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$DIR/../app/app.py"

echo ""
echo "  🎯  CareerAI v2.0"
echo "  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# ── Python check ────────────────────────────────────────────
if command -v python3 &>/dev/null; then
  PYTHON=python3
elif command -v python &>/dev/null; then
  PYTHON=python
else
  echo "  ❌  Python не найден. Установите Python 3.9+"
  exit 1
fi

PY_VER=$($PYTHON -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "  ✅  Python $PY_VER"

# ── Install deps ─────────────────────────────────────────────
echo "  📦  Проверка зависимостей..."
$PYTHON -m pip install -q -r "$DIR/.../requirements.txt" --break-system-packages 2>/dev/null || \
$PYTHON -m pip install -q -r "$DIR/.../requirements.txt" 2>/dev/null || true

echo "  ✅  Зависимости установлены"
echo ""
echo "  🌐  Открывайте: http://localhost:5001"
echo "  🔑  Пароль администратора: admin123"
echo "  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# ── Open browser after 2s ───────────────────────────────────
(sleep 2 && (open "http://localhost:5001" 2>/dev/null || xdg-open "http://localhost:5001" 2>/dev/null || true)) &

# ── Run app ──────────────────────────────────────────────────
$PYTHON "$APP"
